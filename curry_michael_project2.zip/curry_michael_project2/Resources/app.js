var mainWindow = Ti.UI.createWindow({
	backgroundColor: "blue",
	title: "To-Do List"
	
});

var navWindow = Ti.UI.iOS.createNavigationWindow({
	window: mainWindow,
});



var listWindow = Ti.UI.createWindow({
	backgroundColor: "fff",
	title: "List"
});


var tableWindow = Ti.UI.createWindow({
	backgroundColor: "fff",
	title: "List",
	top: 0
});


var todoList = [
	{title: "Shopping", description: "This is an orange"},
	{title: "Homework", description: "This is an apple"},
	{title: "Workout", description: "This is an apple"},
	{title: "Pay Bills", description: "This is an apple"},
	{title: "Clean", description: "This is an apple"},
	{title: "Wash Car", description: "This is an apple"},
	{title: "Walk The Dog", description: "This is an apple"}
];

var table = Ti.UI.createTableView({

	style: Ti.UI.iPhone.TableViewStyle.GROUPED
});

var TodoSelection = Ti.UI.createTableViewSection({
	headerTitle: "WHat I need to do",
	footerTitle: "Now Im finish",
	top: 0
});

var myData = [TodoSelection];

var getDetail = function(){
	var detailWindow = Ti.UI.createWindow({
		backgroundColor: "#fff",
		
	});
	
	var detailText = Ti.UI.createLabel({
		text: this.desc,
		font: {fontSize: 18, fontFamily: "Arial"}
	});
	
	detailWindow.add(detailText);
	detailWindow.open();
	
	var closeButton = Ti.UI.createLabel({
		text: "Close",
		backgroundColor: "blue",
		bottom: 0,
		left: 0,
		right: 0,
		height: 50,
		textAlign: "center"
	});
	
	detailWindow.add(closeButton);
	closeButton.addEventListener("click", function(){detailWindow.close();});
};

for(var i=0, j=todoList.length; i<j; i++){
var todoRow = Ti.UI.createTableViewRow({
	title: todoList[i].title,
	desc: todoList[i].description,
	hasDetail: true
});

todoRow.addEventListener("click", getDetail);
TodoSelection.add(todoRow);
}



var listView = Ti.UI.createView({
	backgroundColor: "#000",
	height: 50,
	width: 200,
	top: 150
});


var listText = Ti.UI.createLabel({
	text : 'List View',
	color : 'white',
	font : {fontSize: 18},
	textAlign : 'center'
});

listView.add(listText);


listView.addEventListener('click', function(){
    navWindow.openWindow(listWindow, {animated:true});
});

var tableView = Ti.UI.createView({
	backgroundColor: "#000",
	height: 50,
	width: 200,
	top: 250
});

var tableText = Ti.UI.createLabel({
	text : 'Table View',
	color : 'white',
	font : {fontSize: 18},
	textAlign : 'center'
});

tableView.add(tableText);

tableView.addEventListener('click', function(){
    navWindow.openWindow(tableWindow, {animated:true});
});

table.setData(myData);

tableWindow.add(table);

mainWindow.add(listView, tableView);

mainWindow.open();

navWindow.openWindow(mainWindow);

navWindow.open();
